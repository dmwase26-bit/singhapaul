const SELLER_WHATSAPP = "https://wa.me/919609819681";

const products = [
  {
    id: "polyfix-rapid-hv-glue",
    name: "Polyfix Rapid HV Glue",
    price: "₹200",
    category: "Industrial Supplies",
    image: "assets/polyfix-rapid-hv-glue.webp",
    description: "Product information currently provided: Polyfix Rapid HV Glue listed at ₹200.",
  },
];

const categories = [
  "Apparel & Garments",
  "Electronics",
  "Home & Kitchen",
  "Beauty & Personal Care",
  "Machinery",
  "Packaging",
  "Agriculture",
  "Food & Beverage",
  "Construction Materials",
  "Industrial Supplies",
];

const productGrid = document.querySelector("#product-grid");
const categoryGrid = document.querySelector("#category-grid");
const productDetail = document.querySelector("#product-detail");
const emptyState = document.querySelector("#empty-state");
const catalogSearch = document.querySelector("#catalog-search");
const heroSearch = document.querySelector("#hero-search");
const searchInput = document.querySelector("#search-input");
const menuToggle = document.querySelector(".menu-toggle");
const primaryNav = document.querySelector("#primary-nav");

function whatsAppUrl(message) {
  return `${SELLER_WHATSAPP}?text=${encodeURIComponent(message)}`;
}

function productMessage(product) {
  return `Hello, I am interested in ${product.name}. The listed price is ${product.price}. Please share wholesale details and availability.`;
}

function renderWhatsAppLinks(root = document) {
  root.querySelectorAll(".whatsapp-link").forEach((link) => {
    const product = products.find((item) => item.id === link.dataset.productId) || products[0];
    link.href = whatsAppUrl(productMessage(product));
    link.target = "_blank";
    link.rel = "noopener";
  });
}

function renderProducts(items) {
  productGrid.innerHTML = items
    .map(
      (product) => `
      <article class="product-card">
        <a href="#product-detail" data-detail-id="${product.id}">
          <img src="${product.image}" alt="${product.name}" />
        </a>
        <div class="product-meta">
          <div>
            <p class="category">${product.category}</p>
            <h3>${product.name}</h3>
          </div>
          <span class="price">${product.price}</span>
        </div>
        <div class="card-actions">
          <a class="button primary whatsapp-link" href="#" data-product-id="${product.id}">BUY NOW</a>
          <a class="button secondary" href="#product-detail" data-detail-id="${product.id}">View Details</a>
        </div>
      </article>
    `
    )
    .join("");
  emptyState.hidden = items.length > 0;
  renderWhatsAppLinks(productGrid);
}

function renderProductDetail(product) {
  productDetail.innerHTML = `
    <img src="${product.image}" alt="${product.name}" />
    <div>
      <p class="eyebrow">Product details</p>
      <h2 id="product-detail-title">${product.name}</h2>
      <p class="price">${product.price}</p>
      <p>${product.description}</p>
      <div class="detail-actions">
        <a class="button primary whatsapp-link" href="#" data-product-id="${product.id}">BUY NOW</a>
        <a class="button secondary whatsapp-link" href="#" data-product-id="${product.id}">CONTACT SELLER ON WHATSAPP</a>
      </div>
      <div class="related">
        <p class="eyebrow">Related products</p>
        <p>Demo information: related products can appear here when more catalog items are added.</p>
      </div>
    </div>
  `;
  renderWhatsAppLinks(productDetail);
}

function renderCategories() {
  categoryGrid.innerHTML = categories.map((category) => `<div class="category-tile">${category}</div>`).join("");
}

function filterProducts(query) {
  const normalized = query.trim().toLowerCase();
  if (!normalized) return products;
  return products.filter((product) =>
    [product.name, product.price, product.category].some((field) => field.toLowerCase().includes(normalized))
  );
}

catalogSearch.addEventListener("input", (event) => {
  renderProducts(filterProducts(event.target.value));
});

heroSearch.addEventListener("submit", (event) => {
  event.preventDefault();
  catalogSearch.value = searchInput.value;
  renderProducts(filterProducts(searchInput.value));
  document.querySelector("#products").scrollIntoView({ behavior: "smooth" });
});

document.addEventListener("click", (event) => {
  const detailLink = event.target.closest("[data-detail-id]");
  if (!detailLink) return;
  const product = products.find((item) => item.id === detailLink.dataset.detailId);
  if (product) renderProductDetail(product);
});

document.querySelector("#enquiry-form").addEventListener("submit", (event) => {
  event.preventDefault();
  const data = new FormData(event.currentTarget);
  const message = [
    "Hello, I want to post a wholesale requirement.",
    `Product required: ${data.get("product") || "Not specified"}`,
    `Quantity: ${data.get("quantity") || "Not specified"}`,
    `Budget: ${data.get("budget") || "Not specified"}`,
    `Location: ${data.get("location") || "Not specified"}`,
    `Additional requirements: ${data.get("requirements") || "Not specified"}`,
  ].join("\n");
  window.open(whatsAppUrl(message), "_blank", "noopener");
});

menuToggle.addEventListener("click", () => {
  const isOpen = primaryNav.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(isOpen));
});

primaryNav.addEventListener("click", () => {
  primaryNav.classList.remove("open");
  menuToggle.setAttribute("aria-expanded", "false");
});

renderProducts(products);
renderCategories();
renderProductDetail(products[0]);
renderWhatsAppLinks();
